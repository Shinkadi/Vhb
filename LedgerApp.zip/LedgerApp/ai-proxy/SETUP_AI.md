# Set up the AI helper (about 10 minutes)

1. Go to console.anthropic.com, sign up, add a few dollars of credit, and create an API key (Settings > API keys). Copy it.
2. Go to dash.cloudflare.com and sign up (free). Open Workers & Pages > Create > Create Worker. Name it e.g. ledger-helper and Deploy.
3. Tap Edit code. Delete everything, paste the whole of worker.js, and Deploy.
4. Open the worker's Settings > Variables and Secrets > Add. Add two Secrets:
   - ANTHROPIC_API_KEY = the key from step 1
   - APP_TOKEN = any password you invent (e.g. 8+ random letters)
   Deploy again.
5. Copy the worker link (looks like https://ledger-helper.yourname.workers.dev).
6. In the app: Notifications & Limits > AI helper. Paste the link and the password, tap Save.
7. In "Ask The Ledger" type a longer question, e.g. "Explain Newton's third law with an example".

Never put the API key in the app or in GitHub.
