// Cloudflare Worker: keeps your Anthropic API key off the phone.
// Needs two secrets: ANTHROPIC_API_KEY and APP_TOKEN (a password you invent).
const SYSTEM = "You are the helper inside The Ledger, a 90-day discipline tracker for a school student. " +
  "Be brief (under 120 words), friendly and practical. Help with study questions, revision plans, habits and focus. " +
  "Use the context about the student's day when it helps. Do not give medical or religious rulings; for those suggest asking a parent, teacher or scholar.";

export default {
  async fetch(req, env) {
    if (req.method !== "POST") return new Response("The Ledger helper is running.");
    if (!env.APP_TOKEN || req.headers.get("x-app-token") !== env.APP_TOKEN)
      return new Response("unauthorized", { status: 401 });
    let body;
    try { body = await req.json(); } catch { return new Response("bad request", { status: 400 }); }
    const messages = (body.messages || []).slice(-9).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 1500),
    }));
    if (!messages.length || messages[0].role !== "user") return new Response("bad request", { status: 400 });
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({
        model: "claude-haiku-5-5", max_tokens: 400,
        system: SYSTEM + "\n\nStudent's day:\n" + String(body.context || "").slice(0, 1800),
        messages,
      }),
    });
    const d = await r.json();
    const text = (d.content || []).map(c => c.text || "").join("") || (d.error && d.error.message) || "No answer.";
    return new Response(JSON.stringify({ text }), { headers: { "content-type": "application/json" } });
  },
};
