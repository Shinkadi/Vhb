package com.ledger.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            c.startForegroundService(Intent(c, MonitorService::class.java))
            Reminders.schedule(c)
        }
    }
}
