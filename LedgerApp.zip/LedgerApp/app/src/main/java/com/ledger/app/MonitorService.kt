package com.ledger.app

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.telecom.TelecomManager

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var fg: String? = null
    private var lastTick = 0L
    private var first = true
    private var exempt: Set<String> = emptySet()
    private var exemptAt = 0L
    private val tick = object : Runnable {
        override fun run() { try { check() } catch (e: Exception) {}; handler.postDelayed(this, 1000) }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "App Lock", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "lock")
            .setContentTitle("The Ledger is guarding your screen time")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        Reminders.schedule(this)
        handler.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }

    /** Apps that never count toward, and are never covered by, the screen-time limit. */
    private fun exemptSet(): Set<String> {
        val now = System.currentTimeMillis()
        if (exempt.isNotEmpty() && now - exemptAt < 60000L) return exempt
        val s = mutableSetOf(
            packageName, "com.android.systemui", "com.android.settings",
            "com.android.incallui", "com.android.phone", "com.android.server.telecom", "com.android.emergency",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer", "com.samsung.android.incallui",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller"
        )
        try { getSystemService(TelecomManager::class.java)?.defaultDialerPackage?.let { s.add(it) } } catch (e: Exception) {}
        try {
            packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                ?.activityInfo?.packageName?.let { s.add(it) }
        } catch (e: Exception) {}
        exempt = s; exemptAt = now
        return s
    }

    private fun lock(reason: String) {
        startActivity(Intent(this, LockActivity::class.java).putExtra("reason", reason)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
    }

    private fun warn(leftMs: Long) {
        val s = Store.p(this); val d = Store.today()
        if (leftMs <= 0) {
            if (s.getString("warn0", "") != d) {
                s.edit().putString("warn0", d).apply()
                Reminders.post(this, 9001, "Screen time limit reached", "That's your ${Store.limitMin(this)} minutes for today.", "limit")
            }
        } else if (leftMs <= 15 * 60000L && s.getString("warn15", "") != d) {
            s.edit().putString("warn15", d).apply()
            Reminders.post(this, 9002, "15 minutes of screen time left", "Wrap up what you're doing.", "limit")
        }
    }

    private fun check() {
        val now = System.currentTimeMillis()
        val dt = if (lastTick == 0L) 0L else minOf(now - lastTick, 2000L)
        lastTick = now
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val ev = usm.queryEvents(now - (if (first) 3600000L else 15000L), now)
        first = false
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            @Suppress("DEPRECATION")
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) fg = e.packageName
            else if (e.eventType == UsageEvents.Event.MOVE_TO_BACKGROUND && e.packageName == fg) fg = null
        }
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        val cur = fg ?: return
        if (cur in exemptSet()) return

        // 1) Total screen time limit (all non-exempt apps)
        Store.addScreen(this, dt)
        val limitMs = Store.limitMin(this) * 60000L
        val left = limitMs - Store.screenMs(this)
        warn(left)
        if (left <= 0) { lock("limit"); return }

        // 2) Distracting apps need earned allowance
        if (cur !in Store.blocked(this)) return
        if (Store.usedMs(this) >= Store.earnedMs(this)) lock("tasks") else Store.addUsed(this, dt)
    }
}
