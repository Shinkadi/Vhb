package com.ledger.app

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.app.AlarmManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient() // enables confirm()/alert() dialogs
        web.addJavascriptInterface(Bridge(), "AndroidLock")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }

    inner class Bridge {
        private fun launch(i: Intent) = runOnUiThread { startActivity(i) }

        @JavascriptInterface fun setEarned(date: String, minutes: Int) {
            Store.p(this@MainActivity).edit().putString("earnedDate", date).putInt("earnedMin", minutes).apply()
        }
        @JavascriptInterface fun setBlocked(csv: String) {
            Store.p(this@MainActivity).edit().putString("blocked", csv).apply()
        }
        @JavascriptInterface fun status(): String {
            val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
            @Suppress("DEPRECATION")
            val usage = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
            return JSONObject()
                .put("usage", usage)
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("earned", Store.earnedMs(this@MainActivity) / 60000)
                .put("used", Store.usedMs(this@MainActivity) / 60000)
                .put("screen", Store.screenMs(this@MainActivity) / 60000)
                .put("limit", Store.limitMin(this@MainActivity))
                .put("pending", Store.pendingLimit(this@MainActivity))
                .put("exact", Build.VERSION.SDK_INT < 31 || (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms())
                .put("notif", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
                .toString()
        }
        @JavascriptInterface fun startService() {
            runOnUiThread { startForegroundService(Intent(this@MainActivity, MonitorService::class.java)) }
        }
        @JavascriptInterface fun openUsage() = launch(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        @JavascriptInterface fun openOverlay() =
            launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        @JavascriptInterface fun setSchedule(json: String) = Reminders.save(this@MainActivity, json)
        @JavascriptInterface fun setLimit(minutes: Int): String = Store.setLimit(this@MainActivity, minutes)
        @JavascriptInterface fun openExact() {
            if (Build.VERSION.SDK_INT >= 31)
                launch(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
        @JavascriptInterface fun requestNotif() {
            if (Build.VERSION.SDK_INT >= 33) runOnUiThread { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        }
        @JavascriptInterface fun getLoc(): String = Store.p(this@MainActivity).getString("loc", "") ?: ""
        @JavascriptInterface fun locate(): String {
            val a = this@MainActivity
            if (a.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 2) }
                return "permission"
            }
            Store.p(a).edit().remove("loc").apply()
            val lm = a.getSystemService(LOCATION_SERVICE) as LocationManager
            fun keep(l: Location) = Store.p(a).edit().putString("loc", "${l.latitude},${l.longitude}").apply()
            var best: Location? = null
            for (pv in lm.getProviders(true)) {
                try { val l = lm.getLastKnownLocation(pv); if (l != null && (best == null || l.time > best!!.time)) best = l }
                catch (e: SecurityException) {}
            }
            if (best != null) { keep(best!!); return "ok" }
            if (Build.VERSION.SDK_INT >= 30) {
                val pv = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else LocationManager.GPS_PROVIDER
                runOnUiThread {
                    try { lm.getCurrentLocation(pv, null, a.mainExecutor) { l -> if (l != null) keep(l) } }
                    catch (e: SecurityException) {}
                }
            }
            return "ok"
        }
        @JavascriptInterface fun askAI(id: Int, url: String, token: String, body: String) {
            if (!url.startsWith("https://")) { aiReply(id, false, "The URL must start with https://"); return }
            Thread {
                try {
                    val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                    c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 45000; c.doOutput = true
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-app-token", token)
                    c.outputStream.use { it.write(body.toByteArray()) }
                    val code = c.responseCode
                    val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                    if (code in 200..299) aiReply(id, true, JSONObject(txt).optString("text", ""))
                    else aiReply(id, false, "Server said $code")
                } catch (e: Exception) { aiReply(id, false, e.message ?: "No internet connection") }
            }.start()
        }
        private fun aiReply(id: Int, ok: Boolean, t: String) = runOnUiThread {
            web.evaluateJavascript("window.__aiDone($id,$ok,${JSONObject.quote(t)})", null)
        }
        @JavascriptInterface fun openBattery() = launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }
}
