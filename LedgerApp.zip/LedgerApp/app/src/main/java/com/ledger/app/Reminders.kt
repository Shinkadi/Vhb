package com.ledger.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONArray

/** Receives the exact alarm and posts the due notifications. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) = Reminders.fire(c)
}

/**
 * The web UI computes upcoming reminders (prayer times, study sessions, habit reminders)
 * and hands the list over as JSON. We keep one alarm armed for the next entry and chain on.
 */
object Reminders {
    class Item(val t: Long, val title: String, val text: String, val ch: String)

    private fun load(c: Context): List<Item> = try {
        val a = JSONArray(Store.p(c).getString("sched", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.getLong("t"), o.getString("title"), o.optString("text"), o.optString("ch", "habit"))
        }
    } catch (e: Exception) { emptyList() }

    fun save(c: Context, json: String) {
        Store.p(c).edit().putString("sched", json).apply()
        schedule(c)
    }

    private fun pending(c: Context) = PendingIntent.getBroadcast(
        c, 7, Intent(c, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(c: Context) {
        val now = System.currentTimeMillis()
        val last = Store.p(c).getLong("lastFired", 0L)
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c)
        val next = load(c).filter { it.t > last && it.t > now - 600000L }.minByOrNull { it.t }
        if (next == null) { am.cancel(pi); return }
        val at = maxOf(next.t, now + 1000L)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun fire(c: Context) {
        val now = System.currentTimeMillis()
        val s = Store.p(c)
        val last = s.getLong("lastFired", 0L)
        val all = load(c).filter { it.t > last && it.t <= now + 30000L }
        all.filter { it.t >= now - 600000L }.forEach { post(c, (it.t / 1000L).toInt(), it.title, it.text, it.ch) }
        if (all.isNotEmpty()) s.edit().putLong("lastFired", all.maxOf { it.t }).apply()
        schedule(c)
    }

    fun post(c: Context, id: Int, title: String, text: String, ch: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = c.getSystemService(NotificationManager::class.java)
        val channel = if (ch == "prayer" || ch == "limit") ch else "habit"
        if (nm.getNotificationChannel(channel) == null) {
            val name = when (channel) {
                "prayer" -> "Prayer reminders"
                "limit" -> "Screen time alerts"
                else -> "Study & habit reminders"
            }
            nm.createNotificationChannel(NotificationChannel(channel, name, NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = android.app.Notification.Builder(c, channel)
            .setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(open).setAutoCancel(true).build()
        nm.notify(id, n)
    }
}
